jQuery(function($) {
    $(document).ready(function() {
        const colorPicker = $('.malec-color-picker');
        colorPicker.wpColorPicker();
    });
});