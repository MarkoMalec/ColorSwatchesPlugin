=== Simple Color Swatches for WooCommerce ===
Contributors: (this should be a list of wordpress.org userid's)
Tags: Color, Swatches
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Very simple and lightweight plugin for WooCommerce to add color swatches to product loop items.